const { app, BrowserWindow, globalShortcut } = require('electron');

let win;
let protectionOn = true;

app.whenReady().then(() => {
  win = new BrowserWindow({
    width: 420,
    height: 300,
    x: 100,
    y: 100,
    transparent: true,
    frame: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    webPreferences: { nodeIntegration: true, contextIsolation: false }
  });

  win.setContentProtection(protectionOn); // excluded from screen capture
  win.loadFile('index.html');

  // Ctrl+Shift+H: show / hide the window
  globalShortcut.register('Control+Shift+H', () => {
    win.isVisible() ? win.hide() : win.show();
  });

  // Ctrl+Shift+P: toggle capture protection (to compare with / without)
  globalShortcut.register('Control+Shift+P', () => {
    protectionOn = !protectionOn;
    win.setContentProtection(protectionOn);
    win.webContents.executeJavaScript(
      `document.getElementById('s').textContent='protection: ${protectionOn}'`
    );
  });

  // Ctrl+Shift+Q: quit
  globalShortcut.register('Control+Shift+Q', () => app.quit());
});

app.on('will-quit', () => globalShortcut.unregisterAll());
app.on('window-all-closed', () => app.quit());
