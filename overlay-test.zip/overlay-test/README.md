# overlay-test

Run:
    npm install
    npm start

Test: share your entire screen in Meet/Zoom (second device as viewer) and check
whether the window is visible to the viewer. Press Ctrl+Shift+P to turn
protection off and confirm the viewer then sees it.
